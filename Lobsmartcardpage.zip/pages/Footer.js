import React from 'react';


export default function Footer() {
    return (
        <>
            <footer className="overflow-hidden foot">

                <div class="container" >
                    <p className='text-center'>
                        © 2023 All Rights Reserved by LaabamOne.
                    </p>
                </div>

            </footer>
        </>
    );
}