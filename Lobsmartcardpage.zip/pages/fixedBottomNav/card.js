import React from "react"
import BottomNav from "./bottomNav"
function Card() {
    return (
      <>
        <li className="nav__item ">
                <a href="" className="nav__link">
                  <i className="bi bi-person-vcard-fill"></i>

                </a>
              </li>
  
      </>
    )
  }
  export default Card
  